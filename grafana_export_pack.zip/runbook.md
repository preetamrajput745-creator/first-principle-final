# Grafana Restore Runbook
1. Ensure Grafana is running.
2. Run ./restore_grafana.sh
3. Copy prometheus_rules.yml to Prometheus config dir.
4. Reload Prometheus (kill -HUP).
