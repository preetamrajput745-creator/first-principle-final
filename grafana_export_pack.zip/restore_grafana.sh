#!/bin/bash
# Restore Dashboards
for f in dashboard-*.json; do
  curl -X POST -H "Content-Type: application/json" -d @$f http://admin:admin@localhost:3000/api/dashboards/db
done
